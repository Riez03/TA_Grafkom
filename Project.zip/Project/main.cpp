// deklarasikan semua header disini
#include <windows.h>
#include <GL/glut.h>
#include "praktikum07.h"

#include <math.h>
#define vX 0.525731112119133696
#define vZ 0.850650808352039932

// inisialisasi variabel untuk transformasi seperti translasi, rotasi atau scaling
float postX = 0.0f;
float postY = 0.0f;
boolean toRight = true;
float angle = 0.0f;					// sudut transformasi kamera
float posX = 0.0f, rotX = 0.0f;	// posisi kamera di sumbu X
float posY = 0.0f, rotY = 0.0f;	// posisi kamera di sumbu Y
float posZ = 5.0f, rotZ = -1.0f;	// posisi kamera di sumbu Z

float objectAngleX = 0.0f;			// sudut tranformasi obyek di sumbu X
float objectAngleY = 0.0f;			// sudut tranformasi obyek di sumbu Y
float objectAngleZ = 0.0f;			// sudut tranformasi obyek di sumbu Z

float objectScaleX = 1.0f;	// skala perbesaran obyek ke arah X
float objectScaleY = 1.0f;	// skala perbesaran obyek ke arah Y
float objectScaleZ = 1.0f;	// skala perbesaran obyek ke arah Z

float objectPositionX = 0.0f;	// posisi obyek di sumbu X
float objectPositionY = 0.0f;	// posisi obyek di sumbu Y
float objectPositionZ = -20.0f;	// posisi obyek di sumbu Z

GLUnurbsObj* theNurb;

GLfloat mat_diffuse[] = { 0.7, 0.7, 0.7, 1.0 };
GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
GLfloat mat_shininess[] = { 100.0 };

// Inisialisasi pembuatan permukaan kurva
Vec3 controlPoint[4][4];
bool showPoints = false;

GLfloat initialRotationAngle = 90.0f; // Sudut rotasi awal dalam derajat

// posisi sumber cahaya
// posisi sumber cahaya utk perspektif
 float position[] = { 0.0f,5.0f,5.0f,1.0f };
 
 int flat = 1; // 0 = smooth shading, 1 = flat shading
int subdiv = 10;

// fungsi untuk melakukan normalisasi koordinat posisi
Vec3 normalize(Vec3 value)
{
	Vec3 result;
	float lengths = sqrt((value.X * value.X) + (value.Y * value.Y)
		+ (value.Z * value.Z));
	result.X = value.X / lengths;
	result.Y = value.Y / lengths;
	result.Z = value.Z / lengths;
	return result;
}

// fungsi untuk melakukan operasi perkalian cross
Vec3 cross(Vec3 value1, Vec3 value2)
{
	Vec3 result;
	result.X = value1.Y * value2.Z - value2.Y * value1.Z;
	result.Y = value1.Z * value2.X - value2.Z * value1.X;
	result.Z = value1.X * value2.Y - value2.X * value1.Y;
	return result;
}

// fungsi untuk menghitung normal
void normface(Vec3 v1, Vec3 v2, Vec3 v3)
{
	Vec3 d1, d2;
	d1.X = v1.X - v2.X; d1.Y = v1.Y - v2.Y; d1.Z = v1.Z - v2.Z;
	d2.X = v2.X - v3.X; d2.Y = v2.Y - v3.Y; d2.Z = v2.Z - v3.Z;
	Vec3 tn = cross(d1, d2);
	tn = normalize(tn);
	glNormal3f(tn.X, tn.Y, tn.Z);
}

// menggambar polygon segitiga dengan sisi normal
void drawTriangleFlat(Vec3 v1, Vec3 v2, Vec3 v3)
{
	glBegin(GL_TRIANGLES);
	normface(v1, v2, v3);
	glVertex3f(v1.X, v1.Y, v1.Z);
	glVertex3f(v2.X, v2.Y, v2.Z);
	glVertex3f(v3.X, v3.Y, v3.Z);
	glEnd();
}

// menggambar polygon segitiga smooth dengan normal
void drawTriangleSmooth(Vec3 v1, Vec3 v2, Vec3 v3)
{
	glBegin(GL_TRIANGLES);
	glNormal3f(v1.X, v1.Y, v1.Z);
	glVertex3f(v1.X, v1.Y, v1.Z);
	glNormal3f(v2.X, v2.Y, v2.Z);
	glVertex3f(v2.X, v2.Y, v2.Z);
	glNormal3f(v3.X, v3.Y, v3.Z);
	glVertex3f(v3.X, v3.Y, v3.Z);
	glEnd();
}

// subdivisi permukaan secara rekursif
// gambar hasil subdivisi segitiganya
void subdivide(Vec3& v1, Vec3& v2, Vec3& v3, int depth)
{
	Vec3 v12, v23, v31;

	if (depth == 0)
	{
		if (flat == 1)
			drawTriangleFlat(v1, v2, v3);
		else
			drawTriangleSmooth(v1, v2, v3);
		return;
	}

	// hitung titik tengah polygon segitiga
	v12.X = (v1.X + v2.X) / 2.0;
	v12.Y = (v1.Y + v2.Y) / 2.0;
	v12.Z = (v1.Z + v2.Z) / 2.0;
	v23.X = (v2.X + v3.X) / 2.0;
	v23.Y = (v2.Y + v3.Y) / 2.0;
	v23.Z = (v2.Z + v3.Z) / 2.0;
	v31.X = (v3.X + v1.X) / 2.0;
	v31.Y = (v3.Y + v1.Y) / 2.0;
	v31.Z = (v3.Z + v1.Z) / 2.0;

	// extrude titik tengahnya
	v12 = normalize(v12);
	v23 = normalize(v23);
	v31 = normalize(v31);

	// subdivisi polygon segitiga secara rekursif
	subdivide(v1, v12, v31, depth - 1);
	subdivide(v2, v23, v12, depth - 1);
	subdivide(v3, v31, v23, depth - 1);
	subdivide(v12, v23, v31, depth - 1);
}

// fungsi untuk menggambar kubus
void drawCube()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glBegin(GL_QUADS);
	// beri warna merah di sisi depan 1
	glColor3f(1.0f, 0.0f, 0.0f);
	// buat sisi depan (kanan mobil belakang)
	glVertex3f(-2.05f, -1.0f, 1.0f);
	glVertex3f(2.3f, -1.0f, 1.0f);
	glVertex3f(2.3f, 0.0f, 1.0f);
	glVertex3f(-2.0f, 0.0f, 1.0f);
	// buat sisi depan (kanan mobil tengah)
//	glVertex3f(1.6f, -1.0f, 1.0f);
//	glVertex3f(2.3f, -1.0f, 1.0f);
//	glVertex3f(2.3f, 0.0f, 1.0f);
//	glVertex3f(1.6f, 1.0f, 1.0f);
//	// buat sisi depan (kanan mobil depan)
	glVertex3f(2.3f, -1.0f, 1.0f);
	glVertex3f(3.7f, -1.0f, 1.0f);
	glVertex3f(3.5f, -0.1f, 1.0f);
	glVertex3f(2.3f, 0.0f, 1.0f);
	// buat sisi depan (kerangka kanan mobil paling depan atas)
	glVertex3f(1.55f, 0.88f, 1.0f);
	glVertex3f(2.15f, 0.0f, 1.0f);
	glVertex3f(2.3f, 0.0f, 1.0f);
	glVertex3f(1.6f, 1.0f, 1.0f);
	// buat sisi depan (kerangka kanan mobil paling belakang)
	glVertex3f(-2.05f, -1.0f, 1.0f);
	glVertex3f(-1.83f, -1.0f, 1.0f);
	glVertex3f(-1.8f, 1.0f, 1.0f);
	glVertex3f(-2.0f, 1.0f, 1.0f);
	// buat sisi depan (kerangka kanan mobil tengah kaca 1-2)
	glVertex3f(0.9f, -1.0f, 1.0f);
	glVertex3f(1.1f, -1.0f, 1.0f);
	glVertex3f(1.1f, 1.0f, 1.0f);
	glVertex3f(0.9f, 1.0f, 1.0f);
	// buat sisi depan (kerangka kanan mobil tengah kaca 2-3)
	glVertex3f(-0.5f, -1.0f, 1.0f);
	glVertex3f(-0.3f, -1.0f, 1.0f);
	glVertex3f(-0.3f, 1.0f, 1.0f);
	glVertex3f(-0.5f, 1.0f, 1.0f);
	// buat sisi depan (kerangka kanan mobil paling atas)
	glVertex3f(-2.01f, 0.88f, 1.0f);
	glVertex3f(1.6f, 0.88f, 1.0f);
	glVertex3f(1.6f, 1.0f, 1.0f);
	glVertex3f(-2.0f, 1.0f, 1.0f);
	// beri warna abu2 di sisi depan 2
	glColor4f(0.5f, 0.5f, 0.5f, 0.5f); // Warna abu2merah dengan alpha = 0.5 (setengah transparan)
	// buat sisi depan (kaca kanan mobil 1)
	glVertex3f(1.1f, 0.0f, 1.0f);
	glVertex3f(2.15f, 0.0f, 1.0f);
	glVertex3f(1.55f, 0.88f, 1.0f);
	glVertex3f(1.1f, 0.88f, 1.0f);
	// buat sisi depan (kaca kanan mobil 2)
	glVertex3f(-0.3f, 0.0f, 1.0f);
	glVertex3f(0.9f, 0.0f, 1.0f);
	glVertex3f(0.9f, 0.88f, 1.0f);
	glVertex3f(-0.3f, 0.88f, 1.0f);
	// buat sisi depan (kaca kanan mobil 3)
	glVertex3f(-1.83f, 0.0f, 1.0f);
	glVertex3f(-0.5f, 0.0f, 1.0f);
	glVertex3f(-0.5f, 0.88f, 1.0f);
	glVertex3f(-1.8f, 0.88f, 1.0f);
	
//	// beri warna hitam di sisi depan 3
//	glColor3f(0.0f, 0.0f, 0.0f);
//	// buat sisi depan (pegangan pintu depan kanan mobil (depan))
//	glVertex3f(1.2f, -0.2f, 1.1f);
//	glVertex3f(1.4f, -0.2f, 1.1f);
//	glVertex3f(1.4f, -0.1f, 1.1f);
//	glVertex3f(1.2f, -0.1f, 1.1f);
//	// buat sisi depan (pegangan pintu depan kanan mobil (samping))
//	glVertex3f(1.2f, -0.2f, 1.1f);
//	glVertex3f(1.4f, -0.2f, 1.1f);
//	glVertex3f(1.4f, -0.1f, 1.1f);
//	glVertex3f(1.2f, -0.1f, 1.1f);
	// beri warna hijau di sisi belakang 1
	glColor3f(1.0f, 0.0f, 0.0f);
	// buat sisi belakang (kiri mobil belakang)
	glVertex3f(-2.05f, -1.0f, -1.0f);
	glVertex3f(2.3f, -1.0f, -1.0f);
	glVertex3f(2.3f, 0.0f, -1.0f);
	glVertex3f(-2.0f, 0.0f, -1.0f);
	// buat sisi belakang (kiri mobil tengah)
//	glVertex3f(1.6f, -1.0f, -1.0f);
//	glVertex3f(2.3f, -1.0f, -1.0f);
//	glVertex3f(2.3f, 0.0f, -1.0f);
//	glVertex3f(1.6f, 1.0f, -1.0f);
	// buat sisi belakang (kiri mobil depan)
	glVertex3f(2.3f, -1.0f, -1.0f);
	glVertex3f(3.7f, -1.0f, -1.0f);
	glVertex3f(3.5f, -0.1f, -1.0f);
	glVertex3f(2.3f, 0.0f, -1.0f);
	// buat sisi depan (kerangka kanan mobil paling depan atas)
	glVertex3f(1.55f, 0.88f, -1.0f);
	glVertex3f(2.15f, 0.0f, -1.0f);
	glVertex3f(2.3f, 0.0f, -1.0f);
	glVertex3f(1.6f, 1.0f, -1.0f);
	// buat sisi depan (kerangka kanan mobil paling belakang)
	glVertex3f(-2.05f, -1.0f, -1.0f);
	glVertex3f(-1.83f, -1.0f, -1.0f);
	glVertex3f(-1.8f, 1.0f, -1.0f);
	glVertex3f(-2.0f, 1.0f, -1.0f);
	// buat sisi depan (kerangka kanan mobil tengah kaca 1-2)
	glVertex3f(0.9f, -1.0f, -1.0f);
	glVertex3f(1.1f, -1.0f, -1.0f);
	glVertex3f(1.1f, 1.0f, -1.0f);
	glVertex3f(0.9f, 1.0f, -1.0f);
	// buat sisi depan (kerangka kanan mobil tengah kaca 2-3)
	glVertex3f(-0.5f, -1.0f, -1.0f);
	glVertex3f(-0.3f, -1.0f, -1.0f);
	glVertex3f(-0.3f, 1.0f, -1.0f);
	glVertex3f(-0.5f, 1.0f, -1.0f);
	// buat sisi depan (kerangka kanan mobil paling atas)
	glVertex3f(-2.01f, 0.88f, -1.0f);
	glVertex3f(1.6f, 0.88f, -1.0f);
	glVertex3f(1.6f, 1.0f, -1.0f);
	glVertex3f(-2.0f, 1.0f, -1.0f);
	// beri warna abu2 di sisi belakang 2
	glColor4f(0.5f, 0.5f, 0.5f, 0.5f); // Warna abu2merah dengan alpha = 0.5 (setengah transparan)
	// buat sisi belakang (kaca kiri mobil 1)
	glVertex3f(1.1f, 0.0f, -1.0f);
	glVertex3f(2.15f, 0.0f, -1.0f);
	glVertex3f(1.55f, 0.88f, -1.0f);
	glVertex3f(1.1f, 0.88f, -1.0f);
	// buat sisi belakang (kaca kiri mobil 2)
	glVertex3f(-0.3f, 0.0f, -1.0f);
	glVertex3f(0.9f, 0.0f, -1.0f);
	glVertex3f(0.9f, 0.88f, -1.0f);
	glVertex3f(-0.3f, 0.88f, -1.0f);
	// buat sisi belakang (kaca kiri mobil 3)
	glVertex3f(-1.83f, 0.0f, -1.0f);
	glVertex3f(-0.5f, 0.0f, -1.0f);
	glVertex3f(-0.5f, 0.88f, -1.0f);
	glVertex3f(-1.8f, 0.88f, -1.0f);
	// beri warna biru di sisi kiri
	glColor3f(0.0f, 0.0f, 1.0f);
	// buat sisi kiri (belakang mobil)
	glVertex3f(-2.05f, -1.0f, 1.0f);
	glVertex3f(-2.05f, -1.0f, -1.0f);
	glVertex3f(-2.0f, 1.0f, -1.0f);
	glVertex3f(-2.0f, 1.0f, 1.0f);
	// beri warna abu2 di sisi kiri
	glColor3f(0.2f, 0.2f, 0.2f);
	// buat sisi kiri (kaca belakang mobil)
	glVertex3f(-2.03f, 0.0f, 0.9f);
	glVertex3f(-2.03f, 0.0f, -0.9f);
	glVertex3f(-2.01f, 0.9f, -0.9f);
	glVertex3f(-2.01f, 0.9f, 0.9f);
	// beri warna putih di sisi kanan 1
	glColor3f(1.0f, 0.0f, 0.0f);
	// buat sisi kanan (rangka kaca depan mobil)
//	glVertex3f(1.6f, 1.0f, 1.0f);
//	glVertex3f(1.6f, 1.0f, -1.0f);
//	glVertex3f(2.3f, 0.0f, -1.0f);
//	glVertex3f(2.3f, 0.0f, 1.0f);
//	buat sisi kanan (rangka kaca kanan depan mobil)
	glVertex3f(1.6f, 1.0f, 1.0f);
	glVertex3f(1.6f, 1.0f, 0.9f);
	glVertex3f(2.3f, 0.0f, 0.9f);
	glVertex3f(2.3f, 0.0f, 1.0f);
	//	buat sisi kanan (rangka kaca kiri depan mobil)
	glVertex3f(1.6f, 1.0f, -1.0f);
	glVertex3f(1.6f, 1.0f, -0.9f);
	glVertex3f(2.3f, 0.0f, -0.9f);
	glVertex3f(2.3f, 0.0f, -1.0f);
	//	buat sisi kanan (rangka kaca atas depan mobil)
	glVertex3f(1.6f, 1.0f, 1.0f);
	glVertex3f(1.6f, 1.0f, -1.0f);
	glVertex3f(1.67f, 0.9f, -1.0f);
	glVertex3f(1.67f, 0.9f, 1.0f);
	// beri warna abu2 di sisi kanan
	glColor4f(0.5f, 0.5f, 0.5f, 0.5f); // Warna abu2merah dengan alpha = 0.5 (setengah transparan)
	// buat sisi kanan (kaca depan mobil)
	glVertex3f(1.67f, 0.9f, 0.9f);
	glVertex3f(1.67f, 0.9f, -0.9f);
	glVertex3f(2.3f, 0.0f, -0.9f);
	glVertex3f(2.3f, 0.0f, 0.9f);
	// beri warna cyan di sisi kanan 2
	glColor3f(0.0f, 1.0f, 0.2f);
	// buat sisi kanan (depan mobil)
	glVertex3f(3.7f, -1.0f, 1.0f);
	glVertex3f(3.7f, -1.0f, -1.0f);
	glVertex3f(3.5f, -0.1f, -1.0f);
	glVertex3f(3.5f, -0.1f, 1.0f);
	// beri warna kuning di sisi atas
	glColor3f(1.0f, 1.0f, 0.0f);
	// buat sisi atas (atas mobil)
	glVertex3f(-2.0f, 1.0f, 1.0f);
	glVertex3f(1.6f, 1.0f, 1.0f);
	glVertex3f(1.6f, 1.0f, -1.0f);
	glVertex3f(-2.0f, 1.0f, -1.0f);
	// beri warna kuning di sisi atas depan
	glColor3f(1.0f, 1.0f, 0.0f);
	// buat sisi atas (atas cap mobil)
	glVertex3f(2.3f, 0.0f, 1.0f);
	glVertex3f(3.5f, -0.1f, 1.0f);
	glVertex3f(3.5f, -0.1f, -1.0f);
	glVertex3f(2.3f, 0.0f, -1.0f);
	// beri warna magenta di sisi bawah
	glColor3f(3.0f, 0.0f, 1.0f);
	// buat sisi bawah (bawah mobil)
	glVertex3f(-2.0f, -1.0f, 1.0f);
	glVertex3f(3.5f, -1.0f, 1.0f);
	glVertex3f(3.5f, -1.0f, -1.0f);
	glVertex3f(-2.0f, -1.0f, -1.0f);
	glEnd();
}

void drawPegangan(){
	glBegin(GL_QUADS);
	// beri warna hitam 
	glColor3f(0.0f, 0.0f, 0.0f);
	// buat sisi kanan depan
	glVertex3f(1.2f, -0.2f, 1.05f);
	glVertex3f(1.4f, -0.2f, 1.05f);
	glVertex3f(1.4f, -0.1f, 1.05f);
	glVertex3f(1.2f, -0.1f, 1.05f);
	// buat sisi kanan samping kanan
	glVertex3f(1.4f, -0.2f, 1.05f);
	glVertex3f(1.4f, -0.2f, 1.01f);
	glVertex3f(1.4f, -0.1f, 1.01f);
	glVertex3f(1.4f, -0.1f, 1.05f);
	// buat sisi kanan samping kiri
	glVertex3f(1.2f, -0.2f, 1.05f);
	glVertex3f(1.2f, -0.2f, 1.01f);
	glVertex3f(1.2f, -0.1f, 1.01f);
	glVertex3f(1.2f, -0.1f, 1.05f);
	// buat sisi kiri depan
	glVertex3f(1.2f, -0.2f, -1.05f);
	glVertex3f(1.4f, -0.2f, -1.05f);
	glVertex3f(1.4f, -0.1f, -1.05f);
	glVertex3f(1.2f, -0.1f, -1.05f);
	// buat sisi kiri samping kiri
	glVertex3f(1.4f, -0.2f, -1.05f);
	glVertex3f(1.4f, -0.2f, -1.01f);
	glVertex3f(1.4f, -0.1f, -1.01f);
	glVertex3f(1.4f, -0.1f, -1.05f);
	// buat sisi kiri samping kanan
	glVertex3f(1.2f, -0.2f, -1.05f);
	glVertex3f(1.2f, -0.2f, -1.01f);
	glVertex3f(1.2f, -0.1f, -1.01f);
	glVertex3f(1.2f, -0.1f, -1.05f);
	glEnd();
}

void drawCylinder(float radius, float height, int slices, int stacks)
{
	glPushMatrix();
	GLUquadricObj* cyl = gluNewQuadric();
	gluQuadricDrawStyle(cyl, GLU_FILL);
	gluQuadricNormals(cyl, GLU_SMOOTH);
	gluQuadricOrientation(cyl, GLU_INSIDE);
	// buat tutup bawah silinder
	glTranslatef(0.0f, -height / 2, 0.0f);
	glRotatef(-90, 1.0f, 0.0f, 0.0f);
	glColor3f(1.0f, 1.0f, 0.0f); // warna kuning
	gluDisk(cyl, 0.0f, radius, slices, stacks);
	// buat badan silinder
	glColor3f(0.0f, 0.5f, 0.5f); // warna merah
	gluCylinder(cyl, radius, 0.0, height, slices, stacks);
	// buat tutup atas silinder
//	glColor3f(1.0f, 1.0f, 0.0f); // warna kuning
//	glTranslatef(0.0f, 0.0f, height);
//	gluDisk(cyl, 0.0f, radius, slices, stacks);
	glPopMatrix();
}

void drawJalan(){
	glBegin(GL_QUADS);
	// beri warna hitam 
	glColor3f(0.2f, 0.2f, 0.2f);
	// buat sisi kanan depan
	glVertex3f(-100.0f, -1.7f, 2.0f);
	glVertex3f(100.0f, -1.7f, 2.0f);
	glVertex3f(100.0f, -1.7f, -2.0f);
	glVertex3f(-100.0f, -1.7f, -2.0f);
	glEnd();
}

void drawLampu(){
	glPushMatrix();
	// operasi transformasi rotasi obyek ke arah atas-bawah
	glRotatef(objectAngleX, 1.0f, 0.0f, 0.0f);
	glScalef(0.1, 0.1, 0.1);
	// set warna obyek ke warna hijau (0.0f, 1.0f, 0.0f)
//	glColor3f(0.0f, 0.3f, 0.5f);
	glColor4f(0.9f, 0.9f, 0.9f, 0.7f); // Warna abu2merah dengan alpha = 0.5 (setengah transparan)
	//
	GLfloat knots[8] = { 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0 };
	glRotatef(initialRotationAngle, 0.0f, 1.0f, 0.0f); // Rotasi di sekitar sumbu Y
	gluBeginSurface(theNurb);
	gluNurbsSurface(theNurb, 8, knots, 8, knots, 4 * 3, 3, &controlPoint[0][0].X, 4, 4, GL_MAP2_VERTEX_3);
	gluEndSurface(theNurb);
	if (showPoints)
	{
		glPointSize(5.0);
		glDisable(GL_LIGHTING);
		glColor3f(1.0, 1.0, 0.0);
		glBegin(GL_POINTS);
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				glVertex3f(controlPoint[i][j].X, controlPoint[i][j].Y, controlPoint[i][j].Z);
			}
		}
		glEnd();
		glEnable(GL_LIGHTING);
	}
	glPopMatrix();
	glPopMatrix();
}

void drawKota(){
	glBegin(GL_QUADS);
	// beri warna merah di sisi depan
	glColor4f(0.8f, 0.8f, 0.8f, 0.7f); // Warna abu2merah dengan alpha = 0.5 (setengah transparan)
	// buat sisi depan
	glVertex3f(-5.0f, -1.0f, 1.0f);
	glVertex3f(5.0f, -1.0f, 1.0f);
	glVertex3f(5.0f, 9.0f, 1.0f);
	glVertex3f(-5.0f, 9.0f, 1.0f);
	// buat sisi belakang
	glVertex3f(-5.0f, -1.0f, -1.0f);
	glVertex3f(5.0f, -1.0f, -1.0f);
	glVertex3f(5.0f, 9.0f, -1.0f);
	glVertex3f(-5.0f, 9.0f, -1.0f);
	// buat sisi kiri
	glVertex3f(-5.0f, -1.0f, 1.0f);
	glVertex3f(-5.0f, -1.0f, -1.0f);
	glVertex3f(-5.0f, 9.0f, -1.0f);
	glVertex3f(-5.0f, 9.0f, 1.0f);
	// buat sisi kanan
	glVertex3f(5.0f, -1.0f, 1.0f);
	glVertex3f(5.0f, -1.0f, -1.0f);
	glVertex3f(5.0f, 9.0f, -1.0f);
	glVertex3f(5.0f, 9.0f, 1.0f);
	// buat sisi atas
	glVertex3f(-5.0f, 9.0f, 1.0f);
	glVertex3f(5.0f, 9.0f, 1.0f);
	glVertex3f(5.0f, 9.0f, -1.0f);
	glVertex3f(-5.0f, 9.0f, -1.0f);
	// buat sisi bawah
	glVertex3f(-5.0f, -1.0f, 1.0f);
	glVertex3f(5.0f, -1.0f, 1.0f);
	glVertex3f(5.0f, -1.0f, -1.0f);
	glVertex3f(-5.0f, -1.0f, -1.0f);
	glEnd();
}

// fungsi untuk menggambar obyek pyramid
void drawObject()
{
	// obyek bisa dimasukkan diantara glPushMatrix() dan glPopMatrix() 
	// fungsinya agar obyek tidak terpengaruh atau mempengaruhi obyek lain
	// saat diwarnai, ditransformasi dan sebagainya
	glPushMatrix();

	glTranslatef(objectPositionX + postX, objectPositionY, objectPositionZ);

	// operasi transformasi scaling obyek 
	// memperbesar atau mengecilkan obyek
	// ke arah sumbu X, Y atau Z
	glScalef(objectScaleX, objectScaleY, objectScaleZ);
	
	// operasi transformasi rotasi obyek ke arah kanan-kiri
	glRotatef(objectAngleY , 0.0f, 1.0f, 0.0f);

	glPushMatrix();

	// operasi transformasi rotasi obyek ke arah atas-bawah
	glRotatef(objectAngleX, 1.0f, 0.0f, 0.0f);

	// set warna obyek ke warna hijau (0.0f, 1.0f, 0.0f)
	glColor3f(1.0f, 0.0f, 0.0f);

	drawCube();// panggil fungsi untuk membuat obyek kubus
	
	glPushMatrix();
	glColor3f(0.0f, 0.0f, 0.0f);
	glTranslatef(3.0, -1.0, -1.0);
	glutSolidTorus(0.3f, 0.4f, 20, 20);
	glPopMatrix();
	
	glTranslatef(-1.0, -1.0, -1.0);
	glutSolidTorus(0.3f, 0.4f, 20, 20);
	
	glPushMatrix();
	glTranslatef( 0.0, 0.0, 2.0);
	glutSolidTorus(0.3f, 0.4f, 20, 20);
	glPopMatrix();
	
	glTranslatef( 4.0, 0.0, 2.0);
	glutSolidTorus(0.3f, 0.4f, 20, 20);
	
	glPushMatrix();
	glTranslatef( -5.2, 1.0, -1.0);
	glRotatef(initialRotationAngle, 0.0f, 1.0f, 0.0f); // Rotasi di sekitar sumbu Y
	glutSolidTorus(0.3f, 0.4f, subdiv, subdiv);
	glPopMatrix();
	
//	glTranslatef( -1.7, 0.8, 0.01);
//	glRotatef(initialRotationAngle, 1.0f, 0.0f, 0.0f); // Rotasi di sekitar sumbu X
//	glutSolidTorus(0.07f, 0.09f, 20, 20);
	
	glTranslatef(-3.0, 1.0, -1.0);
	drawPegangan();
	
	glPushMatrix();
	glTranslatef(-1.4, 0.0, 0.0);
	drawPegangan();
	glPopMatrix();
	
	glTranslatef(0.0 , 0.0, 0.0);
	drawJalan();

	glPushMatrix();
	glTranslatef(3.7 , -0.5, 0.6);
	drawLampu();
	glTranslatef(3.7 , -0.5, -0.6);
	drawLampu();
	glPopMatrix();
	
//	glPushMatrix();
//	glTranslatef(-5.0 , 0.0, -23.0);
//	drawKota();
//	glPopMatrix();
//	glPopMatrix();
	
//	glPushMatrix();
//	glTranslatef(6.0 , 0.0, -23.0);
//	drawKota();
//	glPopMatrix();
//	glPopMatrix();
	
//	glPushMatrix();
//	glTranslatef(3.0 , 0.0, 0.0);
//	drawCylinder(1.0f, 2.0f, 20, 20); // fungsi untuk membuat obyek silinder
//	glPopMatrix();
	
	glPopMatrix();

	glPopMatrix();
}

// taruh semua obyek yang akan digambar di fungsi display()
void display()
{
	// bersihkan dan reset layar dan buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	// posisikan kamera pandang
	// dalam hal ini sumbu Y ada diatas dan posisi kamera pandang di (posX, posY, posZ)
	gluLookAt(posX, posY, posZ, posX + rotX, posY + rotY, posZ + rotZ, 0.0f, 1.0f, 0.0f);

	// panggil fungsi untuk menggambar obyek
//	glTranslatef(0.0 + postX, 0.0, 0.0);
	drawObject();

	// tampilkan obyek ke layar
	// gunakan glFlush() bila memakai single buffer
	// gunakan glutSwapBuffers() bila memakai double buffer
	glutSwapBuffers();
}

// inisialisasikan variabel, pencahayaan, tekstur dan pengaturan kamera pandang di fungsi init()
void init(void)
{
	// aktifkan pencahayaan
//	glEnable(GL_LIGHTING);
//	glEnable(GL_COLOR_MATERIAL);
//	glEnable(GL_LIGHT0);
	
	glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

//	glMatrixMode( GL_PROJECTION );
//	glLoadIdentityMatrix();
//	glMatrixMode( GL_MODELVIEW );
//	glLoadIdentityMatrix();
//	
//	glBegin( GL_QUADS );
//	glTexCoord2f(0,0); glVertex2f(-1,-1);
//	glTexCoord2f(1,0); glVertex2f( 1,-1);
//	glTexCoord2f(1,1); glVertex2f( 1, 1);
//	glTexCoord2f(0,1); glVertex2f(-1, 1);
//	glEnd();
	
	// inisialisasi warna latar belakang layar dalam hal ini warna putih (1.0, 1.0, 1.0, 0.0)
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glEnable(GL_DEPTH_TEST);				// mengaktifkan depth buffer
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, 1.0, 1.0, 100.0);	// set proyeksi ke perspektif
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	// inisialisasi kamera pandang
	gluLookAt(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	
	int u, v;
	for (u = 0; u < 4; u++)
	{
		for (v = 0; v < 4; v++)
		{
			controlPoint[u][v].X = 2.0 * ((GLfloat)u - 1.5);
			controlPoint[u][v].Y = 2.0 * ((GLfloat)v - 1.5);
			if ((u == 1 || u == 2) && (v == 1 || v == 2))
				controlPoint[u][v].Z = 3.0;
			else
				controlPoint[u][v].Z = -3.0;
		}
	}
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
//	glEnable(GL_LIGHTING);
//	glEnable(GL_LIGHT0);
//	glEnable(GL_DEPTH_TEST);
	glEnable(GL_AUTO_NORMAL);
	glEnable(GL_NORMALIZE);
	theNurb = gluNewNurbsRenderer();
	gluNurbsProperty(theNurb, GLU_SAMPLING_TOLERANCE, 25.0);
	gluNurbsProperty(theNurb, GLU_DISPLAY_MODE, GLU_FILL);
	
	
}

// fungsi ini digunakan bila layar akan diresize (default)
void reshape(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45, (GLfloat)w / (GLfloat)h, 1.0, 100.0);
	glMatrixMode(GL_MODELVIEW);
}

// fungsi untuk mengatur masukan dari keyboard 
// untuk arah kiri, kanan, atas, bawah, PgUp, dan PgDn
void keyboard(int key, int x, int y)
{
	float fraction = 0.1f;

	switch (key)
	{
		// masukkan perintah disini bila tombol kiri ditekan
	case GLUT_KEY_LEFT:
		// dalam hal ini perintah rotasi obyek ke kiri sebanyak 1 derajat 
		objectAngleY -= 1.0f;
		glutPostRedisplay();	// update obyek
		break;
		// masukkan perintah disini bila tombol kanan ditekan
	case GLUT_KEY_RIGHT:
		// dalam hal ini perintah rotasi obyek ke kanan sebanyak 1 derajat 
		objectAngleY += 1.0f;
		glutPostRedisplay();	// update obyek
		break;
		// masukkan perintah disini bila tombol atas ditekan
	case GLUT_KEY_UP:
		// dalam hal ini perintah rotasi obyek ke atas sebanyak 1 derajat 
		objectAngleX -= 1.0f;
		glutPostRedisplay();	// update obyek
		break;
		// masukkan perintah disini bila tombol bawah ditekan
	case GLUT_KEY_DOWN:
		// dalam hal ini perintah rotasi obyek ke bawah sebanyak 1 derajat 
		objectAngleX += 1.0f;
		glutPostRedisplay();	// update obyek
		break;
		// zoom in
	case GLUT_KEY_PAGE_UP:
		// masukkan perintah disini bila tombol PgUp ditekan
		posX += rotX * fraction;
		posZ += rotZ * fraction;
		glutPostRedisplay();	// update obyek
		break;
		// zoom out
	case GLUT_KEY_PAGE_DOWN:
		// masukkan perintah disini bila tombol PgDn ditekan
		posX -= rotX * fraction;
		posZ -= rotZ * fraction;
		glutPostRedisplay();	// update obyek
		break;
	case GLUT_KEY_F1:
		subdiv += 5; // lakukan subdivisi
		glutPostRedisplay(); // update obyek
		break;
	case GLUT_KEY_F2:
		subdiv -= 5; // lakukan subdivisi
		glutPostRedisplay(); // update obyek
		break;
	}
	if (subdiv < 0) subdiv = 0;
}

// fungsi untuk mengatur masukan dari keyboard 
void keyboard1(unsigned char key, int x, int y)
{
	float fraction = 0.5f;

	switch (key)
	{
	case 'w':	// bila tombol 'w' pada keyboard ditekan
				// translasi ke atas
		objectPositionY += fraction;
		glutPostRedisplay();
		break;
	case 's': 	// bila tombol 's' pada keyboard ditekan
				// translasi ke bawah
		objectPositionY -= fraction;
		glutPostRedisplay();
		break;
	case 'a':	// bila tombol 'a' pada keyboard ditekan
				// translasi ke kiri
		objectPositionX -= fraction;
		glutPostRedisplay();
		break;
	case 'd':	// bila tombol 'd' pada keyboard ditekan
				// translasi ke kanan
		objectPositionX += fraction;
		glutPostRedisplay();
		break;
	case 'q':	// bila tombol 'q' pada keyboard ditekan
				// translasi ke depan
		objectPositionZ += fraction;
		glutPostRedisplay();
		break;
	case 'e':	// bila tombol 'e' pada keyboard ditekan
				// translasi ke belakang
		objectPositionZ -= fraction;
		glutPostRedisplay();
		break;
	case 't':	// bila tombol 't' pada keyboard ditekan
				// perbesar ke arah sumbu Y
		objectScaleY += 0.1f;
		glutPostRedisplay();
		break;
	case 'g':	// bila tombol 'g' pada keyboard ditekan
				// perkecil ke arah sumbu Y
		objectScaleY -= 0.1f;
		glutPostRedisplay();
		break;
	case 'f':	// bila tombol 'f' pada keyboard ditekan
				// perbesar ke arah sumbu X
		objectScaleX += 0.1f;
		glutPostRedisplay();
		break;
	case 'h':	// bila tombol 'h' pada keyboard ditekan
				// perkecil ke arah sumbu X
		objectScaleX -= 0.1f;
		glutPostRedisplay();
		break;
	case 'r':	// bila tombol 'r' pada keyboard ditekan
				// perbesar ke arah sumbu Z
		objectScaleZ += 0.1f;
		glutPostRedisplay();
		break;
	case 'y':	// bila tombol 'y' pada keyboard ditekan
				// perkecil ke arah sumbu Z
		objectScaleZ -= 0.1f;
		glutPostRedisplay();
		break;
	case 27:	// bila tombol 'esc' pada keyboard ditekan
				// keluar program
		exit(0);
		break;
	}
}

// timer untuk animasi (gunakan bila perlu)
void timer(int value)
{
	glutPostRedisplay();
	glutTimerFunc(50, timer, 0);
	postY += 1.0f;
	if(postX < 5.0f && toRight)
		postX += 0.5f;
	else
		toRight = false;
	
	if(postX > -5.0f && !toRight)
		postX -= 0.5f;
	else
		toRight = true;
	
}

// program utama
int main(int argc, char** argv)
{
	// inisialisasi jendela OpenGL
	// GLUT_SINGLE berarti memakai single buffer
	// GLUT_DOUBLE berarti memakai double buffer
	// GLUT_RGB berarti mode tampilan yang dipakai RGB
	// GLUT_RGBA berarti mode tampilan yang dipakai RGBA
	// GLUT_DEPTH berarti memakai depth buffer
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);

	// set ukuran jendela tampilan
	glutInitWindowSize(480, 480);		// besarnya jendela dalam piksel dalam hal ini 300x300
	glutInitWindowPosition(100, 100);	// posisi jendela dilayar komputer dalam piksel
	// judul jendela (wajib diubah dengan informasi NAMA / NIM - JUDUL PRAKTIKUM masing-masing)
	glutCreateWindow("FAHRIZKY SYIHABUDIN IBRAHIM / 2100018411 - Tugas Akhir GRAFKOM - Objek Mobil 3D ");

	// panggil fungsi init untuk inisialisasi awal
	init();

	// event handler untuk display, reshape dan keyboard
	glutDisplayFunc(display);   // display
	glutReshapeFunc(reshape);   // reshape
	glutSpecialFunc(keyboard);  // keyboard
	glutKeyboardFunc(keyboard1);  // keyboard
//	glutTimerFunc(0, timer, 0); // aktifkan timer bila perlu

	// looping
	glutMainLoop();

	return 0;
}
