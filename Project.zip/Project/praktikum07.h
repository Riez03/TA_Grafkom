// deklarasikan semua header disini
#include <windows.h>
#include <math.h>
#include <GL/glut.h>

// container untuk membuat tipe data 3D (X, Y, Z)
struct Vec3
{
	float X; float Y; float Z;
	Vec3(float x, float y, float z) { X = x; Y = y; Z = z; }
	//
	Vec3() { }
	~Vec3() { }
};

//// vertex data array
//static GLfloat vdata[12][3] =
//{
//	{ -vX, 0.0, vZ },{ vX, 0.0, vZ },{ -vX, 0.0, -vZ },{ vX, 0.0, -vZ },
//	{ 0.0, vZ, vX },{ 0.0, vZ, -vX },{ 0.0, -vZ, vX },{ 0.0, -vZ, -vX },
//	{ vZ, vX, 0.0 },{ -vZ, vX, 0.0 },{ vZ, -vX, 0.0 },{ -vZ, -vX, 0.0 }
//};

// titik-titik segitiga
static int tindices[20][3] = {
	{ 1,4,0 },{ 4,9,0 },{ 4,5,9 },{ 8,5,4 },{ 1,8,4 },
	{ 1,10,8 },{ 10,3,8 },{ 8,3,5 },{ 3,2,5 },{ 3,7,2 },
	{ 3,10,7 },{ 10,6,7 },{ 6,11,7 },{ 6,0,11 },{ 6,1,0 },
	{ 10,1,6 },{ 11,0,9 },{ 2,11,9 },{ 5,2,9 },{ 11,2,7 }
};

//GLfloat mat_specular[] = { 0.0, 0.0, 0.0, 1.0 };
//GLfloat mat_diffuse[] = { 0.8, 0.6, 0.4, 1.0 };
//GLfloat mat_ambient[] = { 0.8, 0.6, 0.4, 1.0 };
//GLfloat mat_shininess = 100.0;

GLfloat light_ambient[] = { 0.2, 0.2, 0.2, 1.0 };
GLfloat light_diffuse[] = { 1.0, 1.0, 1.0, 1.0 };
GLfloat light_specular[] = { 0.0, 0.0, 0.0, 1.0 };

GLfloat light_position1[] = { 1.5, 1.0, -2.0, 0.0 };
GLfloat light_position2[] = { 1.5, 1.0, 2.0, 0.0 };

void markPoint(Vec3 points, Vec3 colors, float width);
bool inverse(float inMat[16], float outMat[16]);
void DotMatrix(float inMat1[16], float inMat2[4], float outMat[4]);

// menggambar setiap titik kontrol kurva
void markPoint(Vec3 points, Vec3 colors, float width)
{
	// tandai setiap titik dengan warna
	glPushMatrix();
	glColor3f(colors.X, colors.Y, colors.Z);

	glBegin(GL_QUADS);
	glVertex3f(points.X - width, points.Y - width, points.Z);
	glVertex3f(points.X + width, points.Y - width, points.Z);
	glVertex3f(points.X + width, points.Y + width, points.Z);
	glVertex3f(points.X - width, points.Y + width, points.Z);
	glEnd();

	glPopMatrix();
}

// fungsi untuk menghitung invers matriks ordo 4x4
bool inverse(float inMat[16], float outMat[16])
{
	float inv[16], det;
	int i;

	inv[0] = 
		inMat[5] * inMat[10] * inMat[15] -
		inMat[5] * inMat[11] * inMat[14] -
		inMat[9] * inMat[6] * inMat[15] +
		inMat[9] * inMat[7] * inMat[14] +
		inMat[13] * inMat[6] * inMat[11] -
		inMat[13] * inMat[7] * inMat[10];

	inv[4] = 
	   -inMat[4] * inMat[10] * inMat[15] +
		inMat[4] * inMat[11] * inMat[14] +
		inMat[8] * inMat[6] * inMat[15] -
		inMat[8] * inMat[7] * inMat[14] -
		inMat[12] * inMat[6] * inMat[11] +
		inMat[12] * inMat[7] * inMat[10];

	inv[8] = 
		inMat[4] * inMat[9] * inMat[15] -
		inMat[4] * inMat[11] * inMat[13] -
		inMat[8] * inMat[5] * inMat[15] +
		inMat[8] * inMat[7] * inMat[13] +
		inMat[12] * inMat[5] * inMat[11] -
		inMat[12] * inMat[7] * inMat[9];

	inv[12] = 
	   -inMat[4] * inMat[9] * inMat[14] +
		inMat[4] * inMat[10] * inMat[13] +
		inMat[8] * inMat[5] * inMat[14] -
		inMat[8] * inMat[6] * inMat[13] -
		inMat[12] * inMat[5] * inMat[10] +
		inMat[12] * inMat[6] * inMat[9];

	inv[1] = 
	   -inMat[1] * inMat[10] * inMat[15] +
		inMat[1] * inMat[11] * inMat[14] +
		inMat[9] * inMat[2] * inMat[15] -
		inMat[9] * inMat[3] * inMat[14] -
		inMat[13] * inMat[2] * inMat[11] +
		inMat[13] * inMat[3] * inMat[10];

	inv[5] = 
		inMat[0] * inMat[10] * inMat[15] -
		inMat[0] * inMat[11] * inMat[14] -
		inMat[8] * inMat[2] * inMat[15] +
		inMat[8] * inMat[3] * inMat[14] +
		inMat[12] * inMat[2] * inMat[11] -
		inMat[12] * inMat[3] * inMat[10];

	inv[9] = 
	   -inMat[0] * inMat[9] * inMat[15] +
		inMat[0] * inMat[11] * inMat[13] +
		inMat[8] * inMat[1] * inMat[15] -
		inMat[8] * inMat[3] * inMat[13] -
		inMat[12] * inMat[1] * inMat[11] +
		inMat[12] * inMat[3] * inMat[9];

	inv[13] = 
		inMat[0] * inMat[9] * inMat[14] -
		inMat[0] * inMat[10] * inMat[13] -
		inMat[8] * inMat[1] * inMat[14] +
		inMat[8] * inMat[2] * inMat[13] +
		inMat[12] * inMat[1] * inMat[10] -
		inMat[12] * inMat[2] * inMat[9];

	inv[2] = 
		inMat[1] * inMat[6] * inMat[15] -
		inMat[1] * inMat[7] * inMat[14] -
		inMat[5] * inMat[2] * inMat[15] +
		inMat[5] * inMat[3] * inMat[14] +
		inMat[13] * inMat[2] * inMat[7] -
		inMat[13] * inMat[3] * inMat[6];

	inv[6] = 
	   -inMat[0] * inMat[6] * inMat[15] +
		inMat[0] * inMat[7] * inMat[14] +
		inMat[4] * inMat[2] * inMat[15] -
		inMat[4] * inMat[3] * inMat[14] -
		inMat[12] * inMat[2] * inMat[7] +
		inMat[12] * inMat[3] * inMat[6];

	inv[10] = 
		inMat[0] * inMat[5] * inMat[15] -
		inMat[0] * inMat[7] * inMat[13] -
		inMat[4] * inMat[1] * inMat[15] +
		inMat[4] * inMat[3] * inMat[13] +
		inMat[12] * inMat[1] * inMat[7] -
		inMat[12] * inMat[3] * inMat[5];

	inv[14] = 
	   -inMat[0] * inMat[5] * inMat[14] +
		inMat[0] * inMat[6] * inMat[13] +
		inMat[4] * inMat[1] * inMat[14] -
		inMat[4] * inMat[2] * inMat[13] -
		inMat[12] * inMat[1] * inMat[6] +
		inMat[12] * inMat[2] * inMat[5];

	inv[3] = 
	   -inMat[1] * inMat[6] * inMat[11] +
		inMat[1] * inMat[7] * inMat[10] +
		inMat[5] * inMat[2] * inMat[11] -
		inMat[5] * inMat[3] * inMat[10] -
		inMat[9] * inMat[2] * inMat[7] +
		inMat[9] * inMat[3] * inMat[6];

	inv[7] = 
		inMat[0] * inMat[6] * inMat[11] -
		inMat[0] * inMat[7] * inMat[10] -
		inMat[4] * inMat[2] * inMat[11] +
		inMat[4] * inMat[3] * inMat[10] +
		inMat[8] * inMat[2] * inMat[7] -
		inMat[8] * inMat[3] * inMat[6];

	inv[11] = 
	   -inMat[0] * inMat[5] * inMat[11] +
		inMat[0] * inMat[7] * inMat[9] +
		inMat[4] * inMat[1] * inMat[11] -
		inMat[4] * inMat[3] * inMat[9] -
		inMat[8] * inMat[1] * inMat[7] +
		inMat[8] * inMat[3] * inMat[5];

	inv[15] = 
		inMat[0] * inMat[5] * inMat[10] -
		inMat[0] * inMat[6] * inMat[9] -
		inMat[4] * inMat[1] * inMat[10] +
		inMat[4] * inMat[2] * inMat[9] +
		inMat[8] * inMat[1] * inMat[6] -
		inMat[8] * inMat[2] * inMat[5];

	det = inMat[0] * inv[0] + inMat[1] * inv[4] + inMat[2] * inv[8] + inMat[3] * inv[12];

	if (det == 0)
		return false;

	det = 1.0 / det;

	for (i = 0; i < 16; i++)
		outMat[i] = inv[i] * det;

	return true;
}

// fungsi untuk perkalian matriks 4x4 dengan 4x1
void DotMatrix(float inMat1[16], float inMat2[4], float outMat[4])
{
	outMat[0] = inMat1[0] * inMat2[0] + inMat1[1] * inMat2[1] +
		inMat1[2] * inMat2[2] + inMat1[3] * inMat2[3];
	outMat[1] = inMat1[4] * inMat2[0] + inMat1[5] * inMat2[1] +
		inMat1[6] * inMat2[2] + inMat1[7] * inMat2[3];
	outMat[2] = inMat1[8] * inMat2[0] + inMat1[9] * inMat2[1] +
		inMat1[10] * inMat2[2] + inMat1[11] * inMat2[3];
	outMat[3] = inMat1[12] * inMat2[0] + inMat1[13] * inMat2[1] +
		inMat1[14] * inMat2[2] + inMat1[15] * inMat2[3];
}

// fungsi untuk membuat kurva spline cubic dari 4 titik kontrol
// point1 sampai point4 = titik kontrol
// nPoint = jumlah titik interpolasi antara point1 sampai point4
void drawSplineCubic(Vec3 point1, Vec3 point2, Vec3 point3, Vec3 point4,
	int nPoint)
{
	// hitung bobot jarak u di masing-masing titik
	float utotal = (abs(point2.X - point1.X) + abs(point3.X - point2.X) +
		abs(point4.X - point3.X));
	float u1 = 0;
	float u2 = abs(point2.X - point1.X) / utotal;
	float u3 = (abs(point2.X - point1.X) + abs(point3.X - point2.X)) / utotal;
	float u4 = 1;
	// hitung inverse matriks dari koefisien u (lihat slide kuliah)
	float inverseMat[16];
	float coeffMat[16] = {
	1.00f, 0.00f, 0.00f, 0.00f,
	1.00f, u2, pow(u2, 2), pow(u2, 3),
	1.00f, u3, pow(u3, 2), pow(u3, 3),
	1.00f, 1.00f, 1.00f, 1.00f };
	bool status = inverse(coeffMat, inverseMat);
	// hitung koefisien cubic au^3 + bu^2 + cu + d
	if (status == true)
	{
		float outMatX[4], outMatY[4], outMatZ[4];
		float inMatX[4] = { point1.X, point2.X, point3.X, point4.X };
		float inMatY[4] = { point1.Y, point2.Y, point3.Y, point4.Y };
		float inMatZ[4] = { point1.Z, point2.Z, point3.Z, point4.Z };
		DotMatrix(inverseMat, inMatX, outMatX);
		DotMatrix(inverseMat, inMatY, outMatY);
		DotMatrix(inverseMat, inMatZ, outMatZ);
		// gambar kurva cubic spline dengan titik kontrol diatas hitung
		// posisi y untuk setiap x di setiap point dengan persamaan diatas
		for (int i = 0; i < nPoint; i++)
		{
			// jeda setiap titik pd bobot u
			float step = 1.0f / nPoint;
			// titik awal
			float pX = point1.X, pY = point1.Y, pZ = point1.Z;
			//
			float u = 0.0f;
			for (int i = 0; i < nPoint; i++)
			{
				// segment kurva cubic spline sebanyak nPoint
				u = u + step;
				glVertex3f(pX, pY, pZ); // gambar titik awal
				// koordinat X pada kurva
				pX = outMatX[3] * pow(u, 3) + outMatX[2] *
					pow(u, 2) + outMatX[1] * u + outMatX[0];
				// koordinat Y pada kurva
				pY = outMatY[3] * pow(u, 3) + outMatY[2] *
					pow(u, 2) + outMatY[1] * u + outMatY[0];
				// koordinat Z pada kurva
				pZ = outMatZ[3] * pow(u, 3) + outMatZ[2] *
					pow(u, 2) + outMatZ[1] * u + outMatZ[0];
				glVertex3f(pX, pY, pZ); // gambar titik akhir
			}
		}
	}
}

// fungsi untuk membuat kurva spline bezier dari 4 titik kontrol
// point1 dan point4 = titik kontrol awal dan akhir
// point2 dan point3 = titik kontrol pembentuk kurva
// nPoint = jumlah titik interpolasi antara point1 sampai point4
void drawSplineBezier(Vec3 point1, Vec3 point2, Vec3 point3,
	Vec3 point4, int nPoint)
{
	// hitung bobot jarak u di masing-masing titik
	float utotal = (abs(point2.X - point1.X) + abs(point3.X - point2.X) +
		abs(point4.X - point3.X));
	float u1 = 0;
	float u2 = abs(point2.X - point1.X) / utotal;
	float u3 = (abs(point2.X - point1.X) + abs(point3.X - point2.X)) /
		utotal;
	float u4 = 1;
	// hitung inverse matriks dari koefisien u (lihat slide kuliah)
	float inverseMat[16];
	float coeffMat[16] = {
	1.0000f, 0.0000f, 0.0000f, 0.0000f,
	1.0000f, 1.0000f, 1.0000f, 1.0000f,
	0.0000f, 1.0000f, 0.0000f, 0.0000f,
	0.0000f, 1.0000f, 2.0000f, 3.0000f };
	bool status = inverse(coeffMat, inverseMat);
	// hitung koefisien
	if (status == true)
	{
		float outMatX[4], outMatY[4], outMatZ[4];
		float inMatX[4] = { point1.X, point4.X,
		1.0f / (u2 - u1) * (point2.X - point1.X),
		1.0f / (u4 - u3) * (point4.X - point3.X) };
		float inMatY[4] = { point1.Y, point4.Y,
		1.0f / (u2 - u1) * (point2.Y - point1.Y),
		1.0f / (u4 - u3) * (point4.Y - point3.Y) };
		float inMatZ[4] = { point1.Z, point4.Z,
		1.0f / (u2 - u1) * (point2.Z - point1.Z),
		1.0f / (u4 - u3) * (point4.Z - point3.Z) };
		DotMatrix(inverseMat, inMatX, outMatX);
		DotMatrix(inverseMat, inMatY, outMatY);
		DotMatrix(inverseMat, inMatZ, outMatZ);
		// gambar kurva cubic spline dengan titik kontrol diatas hitung
		// posisi y untuk setiap x di setiap point dengan persamaan diatas
		for (int i = 0; i < nPoint; i++)
		{
			// jeda setiap titik pd bobot u
			float step = 1.0f / nPoint;
			// titik awal
			float pX = point1.X, pY = point1.Y, pZ = point1.Z;
			//
			float u = 0.0f;
			for (int i = 0; i < nPoint; i++)
			{
				// bentuk segment kurva spline sebanyak nPoint
				u = u + step;
				glVertex3f(pX, pY, pZ); // gambar titik awal
				// koordinat X pada kurva
				pX = outMatX[3] * pow(u, 3) + outMatX[2] *
					pow(u, 2) + outMatX[1] * u + outMatX[0];
				// koordinat Y pada kurva
				pY = outMatY[3] * pow(u, 3) + outMatY[2] *
					pow(u, 2) + outMatY[1] * u + outMatY[0];
				// koordinat Z pada kurva
				pZ = outMatZ[3] * pow(u, 3) + outMatZ[2] *
					pow(u, 2) + outMatZ[1] * u + outMatZ[0];
				glVertex3f(pX, pY, pZ); // gambar titik akhir
			}
		}
	}
}

// fungsi untuk membuat kurva spline catmull-rom dari 4 titik kontrol
// point1 dan point4 = titik kontrol awal dan akhir
// point2 dan point3 = titik kontrol pembentuk kurva
// nPoint = jumlah titik interpolasi antara point1 sampai point4
void drawSplineCatmullRom(Vec3 point1, Vec3 point2, Vec3 point3,
	Vec3 point4, int nPoint)
{
	// hitung bobot jarak u di masing-masing titik
	float utotal = (abs(point2.X - point1.X) + abs(point3.X - point2.X) +
		abs(point4.X - point3.X));
	float u1 = 0;
	float u2 = abs(point2.X - point1.X) / utotal;
	float u3 = (abs(point2.X - point1.X) + abs(point3.X - point2.X)) /
		utotal;
	float u4 = 1;
	// hitung inverse matriks dari koefisien u (lihat slide kuliah)
	float inverseMat[16];
	float coeffMat[16] = {
	1.0000f, 0.0000f, 0.0000f, 0.0000f,
	1.0000f, 1.0000f, 1.0000f, 1.0000f,
	0.0000f, 1.0000f, 0.0000f, 0.0000f,
	0.0000f, 1.0000f, 2.0000f, 3.0000f };
	bool status = inverse(coeffMat, inverseMat);
	// hitung koefisien
	if (status == true)
	{
		float outMatX[4], outMatY[4], outMatZ[4];
		float inMatX[4] = { point1.X, point4.X,
		1.0f / (u3 - u1) * (point3.X - point1.X),
		1.0f / (u4 - u2) * (point4.X - point2.X) };
		float inMatY[4] = { point1.Y, point4.Y,
		1.0f / (u3 - u1) * (point3.Y - point1.Y),
		1.0f / (u4 - u2) * (point4.Y - point2.Y) };
		float inMatZ[4] = { point1.Z, point4.Z,
		1.0f / (u3 - u1) * (point3.Z - point1.Z),
		1.0f / (u4 - u2) * (point4.Z - point2.Z) };
		DotMatrix(inverseMat, inMatX, outMatX);
		DotMatrix(inverseMat, inMatY, outMatY);
		DotMatrix(inverseMat, inMatZ, outMatZ);
		// gambar kurva spline dengan titik kontrol diatas hitung posisi
		// y untuk setiap x di setiap point dengan persamaan diatas
		for (int i = 0; i < nPoint; i++)
		{
			// jeda setiap titik pd bobot u
			float step = 1.0f / nPoint;
			// titik awal
			float pX = point1.X, pY = point1.Y, pZ = point1.Z;
			//
			float u = 0.0f;
			for (int i = 0; i < nPoint; i++)
			{
				// bentuk segment kurva spline sebanyak nPoint
				u = u + step;
				glVertex3f(pX, pY, pZ); // gambar titik awal
				// koordinat X pada kurva
				pX = outMatX[3] * pow(u, 3) + outMatX[2] *
					pow(u, 2) + outMatX[1] * u + outMatX[0];
				// koordinat Y pada kurva
				pY = outMatY[3] * pow(u, 3) + outMatY[2] *
					pow(u, 2) + outMatY[1] * u + outMatY[0];
				// koordinat Z pada kurva
				pZ = outMatZ[3] * pow(u, 3) + outMatZ[2] *
					pow(u, 2) + outMatZ[1] * u + outMatZ[0];
				glVertex3f(pX, pY, pZ); // gambar titik akhir
			}
		}
	}
}
